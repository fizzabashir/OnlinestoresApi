﻿
namespace WebApplication3.Models.DTOs
{
    public class OrdersDTO
    {
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
    }

}
