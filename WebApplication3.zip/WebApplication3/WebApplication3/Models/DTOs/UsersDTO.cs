﻿namespace WebApplication3.Models.DTOs
{
    
        public class UserDTO
        {
            public int Id { get; set; } // If you want to include ID for updates
            public string Username { get; set; }
            public string Email { get; set; }
            
        }
    
}

