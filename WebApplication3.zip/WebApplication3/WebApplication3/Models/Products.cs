﻿
        namespace WebApplication3.Models
    {
        public class Product
        {
            public int Id { get; set; }              // Primary key
            public string Name { get; set; }         // Product name
            public string Description { get; set; }  // Product description
            public decimal Price { get; set; }       // Product price
            public int Stock { get; set; }           // Available stock
            public DateTime CreatedDate { get; set; } // Date of creation
        }
    }


