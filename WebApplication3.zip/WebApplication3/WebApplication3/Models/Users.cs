﻿

namespace WebApplication3.Models
{
    public class User
    {
        public int Id { get; set; }                // Primary key
        public string Username { get; set; }       // User's username
        public string Password { get; set; }       // User's password (ensure to hash this)
        public string Email { get; set; }          // User's email address
        public DateTime CreatedDate { get; set; }  // Date of account creation

    }
}
