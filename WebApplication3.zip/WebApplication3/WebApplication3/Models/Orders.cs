﻿

namespace WebApplication3.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }

        public virtual Product Product { get; set; } // Navigation property
        public virtual User User { get; set; }       // Navigation property
    }

}
