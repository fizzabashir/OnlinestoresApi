﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Models.DTOs;
using WebApplication3.Models;


namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly OnlinestoresContext db;

        public OrdersController(OnlinestoresContext _db)
        {
            db = _db;
        }

        [HttpGet]
        public IActionResult GetOrders()
        {
            var orders = db.Orders.Include(o => o.Product) // Include product details
                                  .Include(o => o.User)    // Include user details
                                  .ToList();
            return Ok(orders);
        }

        [HttpGet("{id}")]
        public IActionResult GetOrderDetails(int id)
        {
            var order = db.Orders.Include(o => o.Product)
                                  .Include(o => o.User)
                                  .FirstOrDefault(x => x.Id == id);
            if (order == null)
            {
                return NotFound();
            }

            return Ok(order);
        }

        [HttpGet("paged/{pageNo}/{pageSize}")] // Paged results
        public IActionResult GetOrders(int pageNo, int pageSize)
        {
            int pageNumber = pageNo < 1 ? 1 : pageNo;
            int pageSizeValue = pageSize < 1 ? 1 : pageSize;

            var orders = db.Orders.Include(o => o.Product)
                                  .Include(o => o.User)
                                  .Skip((pageNumber - 1) * pageSizeValue)
                                  .Take(pageSizeValue)
                                  .ToList();

            return Ok(orders);
        }

        [HttpPost]
        public IActionResult AddOrder(OrdersDTO orderData)
        {
            if (orderData == null)
            {
                return BadRequest("Order data is null.");
            }
           

            var order = new Order() // Ensure 'Order' is the correct class name
            {
                UserID = orderData.UserID,
                ProductID = orderData.ProductID,
                Quantity = orderData.Quantity,
                OrderDate = DateTime.UtcNow // Assuming OrderDate exists in your model
            };

            db.Orders.Add(order);
            db.SaveChanges();

            return CreatedAtAction(nameof(GetOrderDetails), new { id = order.Id }, order); // 201 Created
        }

        [HttpPut("{id}")]
        public IActionResult EditOrder(int id, OrdersDTO orderData)
        {
            if (orderData == null || id <= 0)
            {
                return BadRequest("Invalid order data.");
            }

            var order = db.Orders.Find(id);
            if (order == null)
            {
                return NotFound();
            }

            order.UserID = orderData.UserID;
            order.ProductID = orderData.ProductID;
            order.Quantity = orderData.Quantity;

            db.Orders.Update(order);
            db.SaveChanges();

            return Ok(order);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOrder(int id)
        {
            var order = db.Orders.Find(id);

            if (order == null)
            {
                return NotFound();
            }

            db.Orders.Remove(order);
            db.SaveChanges();

            return NoContent(); // 204 No Content
        }
    }
}
