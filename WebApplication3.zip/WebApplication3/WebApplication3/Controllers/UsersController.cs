﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Models.DTOs;
using WebApplication3.Models;


namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly OnlinestoresContext db;

        public UsersController(OnlinestoresContext _db)
        {
            db = _db;
        }

        // GET: api/users
        [HttpGet]
        public IActionResult GetUsers()
        {
            var users = db.Users.ToList(); // Adjust if you have specific includes
            return Ok(users);
        }

        // GET: api/users/{id}
        [HttpGet("{id}")]
        public IActionResult GetUserDetails(int id)
        {
            var user = db.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        // POST: api/users
        [HttpPost]
        public IActionResult AddUser(UserDTO userData)
        {
            if (userData == null)
            {
                return BadRequest("User data is null.");
            }

            var user = new User // Ensure 'User' is the correct class name
            {
                Username = userData.Username,
                Email = userData.Email,
                // Add other properties as necessary
            };

            db.Users.Add(user);
            db.SaveChanges();

            return CreatedAtAction(nameof(GetUserDetails), new { id = user.Id }, userData); // Return the submitted data
        }

        // PUT: api/users/{id}
        [HttpPut("{id}")]
        public IActionResult EditUser(int id, UserDTO userData)
        {
            if (userData == null || id <= 0)
            {
                return BadRequest("Invalid user data.");
            }

            var user = db.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            user.Username = userData.Username;
            user.Email = userData.Email;
            // Update other properties as necessary

            db.Users.Update(user);
            db.SaveChanges();

            return Ok(user);
        }

        // DELETE: api/users/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            var user = db.Users.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            db.Users.Remove(user);
            db.SaveChanges();

            return NoContent(); // 204 No Content
        }
    }
}
