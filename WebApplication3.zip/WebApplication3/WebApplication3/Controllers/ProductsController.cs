﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Models.DTOs;
using WebApplication3.Models; 

namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly OnlinestoresContext db;

        public ProductsController(OnlinestoresContext _db)
        {
            db = _db;
        }

        [HttpGet]
        public IActionResult GetProducts()
        {
            var products = db.Products.ToList(); // Use pluralized DbSet
            return Ok(products);
        }

        [HttpGet("{id}")]
        public IActionResult GetProductDetails(int id)
        {
            var product = db.Products.FirstOrDefault(x => x.Id == id); // Use pluralized DbSet
            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        [HttpGet("paged/{pageNo}/{pageSize}")]
        public IActionResult GetProducts(int pageNo, int pageSize)
        {
            int pageNumber = pageNo < 1 ? 1 : pageNo;
            int pageSizeValue = pageSize < 1 ? 1 : pageSize;

            var products = db.Products
                .Skip((pageNumber - 1) * pageSizeValue)
                .Take(pageSizeValue)
                .ToList();

            return Ok(products);
        }

        [HttpPost]
        public IActionResult AddProduct([FromBody] ProductsDTO productData)
        {
            if (productData == null)
            {
                return BadRequest("Invalid product data.");
            }

            var product = new Product() // Ensure 'Products' is the correct class name
            {
                Name = productData.Name,
                Description = productData.Description,
                Price = productData.Price,
                Stock = productData.Stock,
                CreatedDate = DateTime.UtcNow // Assuming CreatedDate exists in your model
            };

            db.Products.Add(product); // Use pluralized DbSet
            db.SaveChanges();

            return CreatedAtAction(nameof(GetProductDetails), new { id = product.Id }, product); // 201 Created
        }

        [HttpPut("{id}")]
        public IActionResult EditProduct(int id, [FromBody] ProductsDTO productData)
        {
            if (productData == null || id <= 0)
            {
                return BadRequest("Invalid product data.");
            }

            var product = db.Products.Find(id); // Use pluralized DbSet
            if (product == null)
            {
                return NotFound();
            }

            product.Name = productData.Name;
            product.Description = productData.Description;
            product.Price = productData.Price;
            product.Stock = productData.Stock;

            db.Products.Update(product); 
            db.SaveChanges();

            return Ok(product);
        }
        [HttpGet]
        public IActionResult GetProduct()
        {
            var products = db.Products.ToList(); 
            return Ok(products);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var product = db.Products.Find(id); // Use pluralized DbSet

            if (product == null)
            {
                return NotFound();
            }

            db.Products.Remove(product); // Use pluralized DbSet
            db.SaveChanges();

            return NoContent(); // 204 No Content
        }
    }
}
