﻿using Microsoft.EntityFrameworkCore;
using WebApplication3.Models;

public class OnlinestoresContext : DbContext
{
    public OnlinestoresContext(DbContextOptions<OnlinestoresContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Product> Products { get; set; }
    public virtual DbSet<Order> Orders { get; set; }  // Include Orders DbSet
    public virtual DbSet<User> Users { get; set; }    // Include Users DbSet
}
